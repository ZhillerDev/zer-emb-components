#include "boot_flash.h"
#include "delay.h"

// ========================== flash 相关工具函数定义 ==========================

void flash_erase_sectors(u8 startSector,u8 sectorLen);



// ========================== flash 擦除与初始化 ==========================

/**
 * @brief  解锁Flash，以便进行写入操作
 * @details 此函数用于解锁Flash，以便可以对Flash进行写入操作。
 *         首先，调用HAL_FLASH_Unlock()函数来解锁Flash。
 *         然后，使用__HAL_FLASH_CLEAR_FLAG()宏来清除所有可能存在的挂起的Flash标志位。
 *         这些标志位包括：
 *         - FLASH_FLAG_EOP：操作结束标志
 *         - FLASH_FLAG_OPERR：操作错误标志
 *         - FLASH_FLAG_WRPERR：写保护错误标志
 *         - FLASH_FLAG_PGAERR：编程对齐错误标志
 *         - FLASH_FLAG_PGPERR：编程错误标志
 *         - FLASH_FLAG_PGSERR：编程序列错误标志
 * @param  无
 * @retval 无
 */
void Flash_Init(void){
	HAL_FLASH_Unlock();
	// Clear pending flags (if any)
	__HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR | 
												 FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR | FLASH_FLAG_PGSERR);
}

/**
 * @brief  擦除整个应用程序Flash区域
 * @param  None
 * @retval 0: 擦除成功
 *         1: 擦除失败，参数错误或擦除过程中发生错误
 * @details 该函数用于擦除从应用程序起始地址开始的所有Flash扇区，直到最后一个扇区。
 */
uint32_t Flash_Erase_All(void)
{
    uint32_t startSector = Flash_GetSector(FLASH_APP_START_ADDR);  // 获取应用程序起始地址对应的扇区号

    // 检查起始扇区号是否在有效范围内，以及是否为4的倍数（确保是正确的扇区起始地址）
    if (startSector < FLASH_START_ADDR || startSector >= FLASH_END_ADDR || startSector % 4)
    {
        return 1;  // 返回1表示参数错误
    }

    // 擦除从起始扇区到FLASH_Sector_11的所有扇区
    flash_erase_sectors(startSector, 11 - startSector);

    return 0;  // 返回0表示擦除成功
}

/**
 * @brief  擦除指定固件区域的Flash扇区
 * @param  firmwareAddr: 固件起始地址
 * @param  firmwareSize: 固件大小
 * @retval 0: 擦除成功
 *         1: 擦除失败，参数错误或擦除过程中发生错误
 * @details 该函数用于擦除指定地址和大小的固件区域所涉及的Flash扇区。
 */
uint32_t Flash_Erase_Firmware(uint32_t firmwareAddr, uint32_t firmwareSize)
{
    uint32_t startSector = Flash_GetSector(firmwareAddr);  // 获取固件起始地址对应的扇区号
    uint32_t endSector = Flash_GetSector(firmwareAddr + firmwareSize);  // 获取固件结束地址对应的扇区号
    uint8_t sectorLen = endSector - startSector;  // 计算需要擦除的扇区数量

    // 检查结束扇区号是否超出最大扇区号，固件起始地址是否小于应用程序起始地址，以及起始扇区号是否为4的倍数
    if (endSector > FLASH_SECTOR_11 || firmwareAddr <= FLASH_APP_START_ADDR || startSector % 4)
    {
        return 1;  // 返回1表示参数错误
    }

    // 擦除从起始扇区到结束扇区的扇区
    flash_erase_sectors(startSector, sectorLen);

    return 0;  // 返回0表示擦除成功
}



// ========================== flash 读写 ==========================

//读取指定地址的字(32位数据) 
//faddr:读地址 
//返回值:对应数据.
u32 Flash_ReadWord(u32 faddr)
{
	return *(vu32*)faddr; 
}

//获取某个地址所在的flash扇区
//addr:flash地址
//返回值:0~11,即addr所在的扇区
u8 Flash_GetSector(u32 addr)
{
	if(addr<ADDR_FLASH_SECTOR_1)return FLASH_SECTOR_0;
	else if(addr<ADDR_FLASH_SECTOR_2)return FLASH_SECTOR_1;
	else if(addr<ADDR_FLASH_SECTOR_3)return FLASH_SECTOR_2;
	else if(addr<ADDR_FLASH_SECTOR_4)return FLASH_SECTOR_3;
	else if(addr<ADDR_FLASH_SECTOR_5)return FLASH_SECTOR_4;
	else if(addr<ADDR_FLASH_SECTOR_6)return FLASH_SECTOR_5;
	else if(addr<ADDR_FLASH_SECTOR_7)return FLASH_SECTOR_6;
	else if(addr<ADDR_FLASH_SECTOR_8)return FLASH_SECTOR_7;
	else if(addr<ADDR_FLASH_SECTOR_9)return FLASH_SECTOR_8;
	else if(addr<ADDR_FLASH_SECTOR_10)return FLASH_SECTOR_9;
	else if(addr<ADDR_FLASH_SECTOR_11)return FLASH_SECTOR_10;   
	return FLASH_SECTOR_11;	
}

//从指定地址开始写入指定长度的数据
//特别注意:因为STM32F4的扇区实在太大,没办法本地保存扇区数据,所以本函数
//         写地址如果非0XFF,那么会先擦除整个扇区且不保存扇区数据.所以
//         写非0XFF的地址,将导致整个扇区数据丢失.建议写之前确保扇区里
//         没有重要数据,最好是整个扇区先擦除了,然后慢慢往后写. 
//该函数对OTP区域也有效!可以用来写OTP区!
//OTP区域地址范围:0X1FFF7800~0X1FFF7A0F(注意：最后16字节，用于OTP数据块锁定，别乱写！！)
//WriteAddr:起始地址(此地址必须为4的倍数!!)
//pBuffer:数据指针
//NumToWrite:字(32位)数(就是要写入的32位数据的个数.) 
u32 Flash_WriteLen(u32 WriteAddr,u32 *pBuffer,u32 NumToWrite)	
{ 
	FLASH_EraseInitTypeDef FlashEraseInit;
	HAL_StatusTypeDef FlashStatus=HAL_OK;
	u32 SectorError=0;
	u32 addrx=0;
	u32 endaddr=0;	
	if(WriteAddr<FLASH_START_ADDR||WriteAddr%4) return(1);	//非法地址
    
	HAL_FLASH_Unlock();             //解锁	
	addrx=WriteAddr;				//写入的起始地址
	endaddr=WriteAddr+NumToWrite*4;	//写入的结束地址
    
	if(addrx<0X1FFF0000)
	{
		while(addrx<endaddr)		//扫清一切障碍.(对非FFFFFFFF的地方,先擦除)
		{
			 if(Flash_ReadWord(addrx)!=0XFFFFFFFF)//有非0XFFFFFFFF的地方,要擦除这个扇区
			{   
				FlashEraseInit.TypeErase=FLASH_TYPEERASE_SECTORS;       //擦除类型，扇区擦除 
				FlashEraseInit.Sector=Flash_GetSector(addrx);   //要擦除的扇区
				FlashEraseInit.NbSectors=1;                             //一次只擦除一个扇区
				FlashEraseInit.VoltageRange=FLASH_VOLTAGE_RANGE_3;      //电压范围，VCC=2.7~3.6V之间!!
				if(HAL_FLASHEx_Erase(&FlashEraseInit,&SectorError)!=HAL_OK) 
				{
					return(1);
				}
				}else addrx+=4;
				FLASH_WaitForLastOperation(FLASH_WAITETIME);                //等待上次操作完成
		}
	}
	FlashStatus=FLASH_WaitForLastOperation(FLASH_WAITETIME);            //等待上次操作完成
	if(FlashStatus==HAL_OK)
	{
		 while(WriteAddr<endaddr)//写数据
		 {
			if(HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD,WriteAddr,*pBuffer)!=HAL_OK)//写入数据
			{ 
				return(1);
			}
			WriteAddr+=4;
			pBuffer++;
		}  
	}
	HAL_FLASH_Lock();           //上锁
	return(0);
} 

//从指定地址开始读出指定长度的数据
//ReadAddr:起始地址
//pBuffer:数据指针
//NumToRead:字(32位)数
u32 Flash_Read(u32 ReadAddr,u32 *pBuffer,u32 NumToRead)   	
{
	u32 i;
	for(i=0;i<NumToRead;i++)
	{
		pBuffer[i]=Flash_ReadWord(ReadAddr);//读取4个字节.
		ReadAddr+=4;//偏移4个字节.	
	}
	return(0);
}


// ========================== 工具方法 ==========================

/**
 * @brief  擦除指定范围的Flash扇区
 * @param  startSector: 要擦除的起始扇区编号
 * @param  sectorLen: 要擦除的扇区数量
 * @retval 无
 * @details 该函数用于擦除从startSector开始的连续sectorLen个扇区。
 *          使用STM32 HAL库函数进行扇区擦除，并处理擦除过程中可能出现的错误。
 */
void flash_erase_sectors(uint8_t startSector, uint8_t sectorLen)
{
    FLASH_EraseInitTypeDef FlashEraseInit;
    uint32_t SectorError = 0;

    /* 配置擦除参数 */
    FlashEraseInit.TypeErase = FLASH_TYPEERASE_SECTORS;       // 擦除类型，扇区擦除
    FlashEraseInit.Sector = startSector;                      // 要擦除的起始扇区
    FlashEraseInit.NbSectors = sectorLen;                     // 要擦除的扇区数量
    FlashEraseInit.VoltageRange = FLASH_VOLTAGE_RANGE_3;      // 电压范围，适用于VCC=2.7~3.6V

    /* 解锁Flash */
    HAL_FLASH_Unlock();

    /* 执行擦除操作 */
    if (HAL_FLASHEx_Erase(&FlashEraseInit, &SectorError) != HAL_OK)
    {
        /* 如果擦除操作失败，则直接返回 */
        return;
    }

    /* 等待Flash操作完成 */
    FLASH_WaitForLastOperation(FLASH_WAITETIME);

    /* 锁定Flash */
    HAL_FLASH_Lock();
}
