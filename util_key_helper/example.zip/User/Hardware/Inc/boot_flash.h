#ifndef __BOOT_FLASH_H__
#define __BOOT_FLASH_H__

#include "sys.h"

#include "stm32f4xx_hal.h"
#include "stm32f4xx_hal_flash.h"
#include "stm32f4xx_hal_flash_ex.h"

// FLASH 基本宏定义
#define FLASH_START_ADDR 						0x8000000 			// STM32F4 FLASH 起始地址
#define FLASH_END_ADDR   						0x80FFFFF				// STM32F4 FLASH 结束地址
#define FLASH_BOOTLOADER_SIZE				0x10000					// Bootloader大小 64KB
#define FLASH_WAITETIME  						50000          	// FLASH等待超时时间

// APP 应用层 - 192KB
#define FLASH_APP_START_ADDR 				0x8020000
#define FLASH_APP_SIZE							0x30000

// DOWNLOAD 下载层 - 128KB
#define FLASH_DOWNLOAD_START_ADDR		(FLASH_APP_START_ADDR + FLASH_APP_SIZE)
#define FLASH_DOWNLOAD_SIZE					0x20000

// ORIGIN 原厂固件层 - 128KB
#define FLASH_ORIGIN_START_ADDR			(FLASH_DOWNLOAD_START_ADDR + FLASH_DOWNLOAD_SIZE)
#define FLASH_ORIGIN_SIZE						0x20000

// 剩余空间
#define FLASH_REMAIN_START_ADDR			(FLASH_ORIGIN_START_ADDR+FLASH_ORIGIN_SIZE)
#define FLASH_REMAIN_SIZE						(ADDR_FLASH_SECTOR_11-FLASH_REMAIN_START_ADDR+1)

// FLASH 扇区的起始地址
// 注意：你只需要读取到11扇区即可，后面是固化的系统存储器和OTP，绝对不可以擦写！！！
// 下方扇区根据STM32F4片上Flash扇区分布一一划分
#define ADDR_FLASH_SECTOR_0     ((u32)0x08000000) 	//扇区0起始地址, 16 Kbytes  
#define ADDR_FLASH_SECTOR_1     ((u32)0x08004000) 	//扇区1起始地址, 16 Kbytes  
#define ADDR_FLASH_SECTOR_2     ((u32)0x08008000) 	//扇区2起始地址, 16 Kbytes  
#define ADDR_FLASH_SECTOR_3     ((u32)0x0800C000) 	//扇区3起始地址, 16 Kbytes  
#define ADDR_FLASH_SECTOR_4     ((u32)0x08010000) 	//扇区4起始地址, 64 Kbytes  
#define ADDR_FLASH_SECTOR_5     ((u32)0x08020000) 	//扇区5起始地址, 128 Kbytes  
#define ADDR_FLASH_SECTOR_6     ((u32)0x08040000) 	//扇区6起始地址, 128 Kbytes  
#define ADDR_FLASH_SECTOR_7     ((u32)0x08060000) 	//扇区7起始地址, 128 Kbytes  
#define ADDR_FLASH_SECTOR_8     ((u32)0x08080000) 	//扇区8起始地址, 128 Kbytes  
#define ADDR_FLASH_SECTOR_9     ((u32)0x080A0000) 	//扇区9起始地址, 128 Kbytes  
#define ADDR_FLASH_SECTOR_10    ((u32)0x080C0000) 	//扇区10起始地址,128 Kbytes  
#define ADDR_FLASH_SECTOR_11    ((u32)0x080E0000) 	//扇区11起始地址,128 Kbytes 

 
void Flash_Init(void); 

u32 Flash_Erase_All(void);
u32 Flash_Erase_Firmware(u32 firmwareAddr,u32 firmwareSize);

u8 Flash_GetSector(u32 addr);
u32 Flash_ReadWord(u32 faddr);		  	//读出字  
u32 Flash_WriteLen(u32 WriteAddr,u32 *pBuffer,u32 NumToWrite);		//从指定地址开始写入指定长度的数据
u32 Flash_ReadLen(u32 ReadAddr,u32 *pBuffer,u32 NumToRead);   		//从指定地址开始读出指定长度的数据

#endif
