#ifndef CORE_INC_H
#define CORE_INC_H

#include "stm32f4xx.h"
#include "stm32f4xx_hal.h"

#include "fatfs.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

#include "sys.h"
#include "pins.h"
#include "delay.h"
#include "global.h"

// lcd
#include "lcd.h"
#include "i2c_soft.h"
#include "touch.h"
#include "24cxx.h"
#include "util_lcd.h"

// lvgl
#include "lvgl.h"            
#include "lv_port_disp.h"   
#include "lv_port_indev.h" 

#endif /* CORE_INC_H */