#ifndef CORE_H
#define CORE_H

#include "core_inc.h"
#include "core_gui.h"

void Core_Init(void);
void Core_Loop(void);

#endif /* CORE_H */