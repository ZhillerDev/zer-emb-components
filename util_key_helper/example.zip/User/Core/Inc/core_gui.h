#ifndef CORE_GUI_H
#define CORE_GUI_H

#include "core_inc.h"

void Core_GUIInit(void);

void Core_LVGL_Setup(void);
void Core_LVGL_Update(void);
void Core_LVGL_Calibration(void);

void lvgl_test_arc(void);
void lvgl_test_bar(void);
void lvgl_test_btn(void);
void lvgl_test_btnmatrix(void);
void lvgl_test_flex(void);
void lvgl_test_grid(void);

#endif //CORE_GUI_H