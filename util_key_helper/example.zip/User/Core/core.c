#include "core.h"

void Core_Init(void){
	Delay_Init(168);
	//systick_init();
	
	Core_GUIInit();
}

void Core_Loop(void){
	Core_LVGL_Setup();
	while(1){
		Core_LVGL_Update();
		Core_LVGL_Calibration();
	}
}